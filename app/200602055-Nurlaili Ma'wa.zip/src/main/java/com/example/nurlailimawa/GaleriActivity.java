package com.example.nurlailimawa;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import com.example.nurlailimawa.model.Buah;

public class GaleriActivity extends AppCompatActivity {

    List<Buah> buahs;
    int indeksTampil = 0;
    String jenisBuah;
    Button btnPertama,btnTerakhir,btnSebelumnya,btnBerikutnya;
    TextView txJenis,txAsal,txDeskripsi,txJudul;
    ImageView ivFotoBuah;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_buah);
        Intent intent = getIntent();
        jenisBuah = intent.getStringExtra(MainActivity.JENIS_GALERI_KEY);
        buahs = DataProvider.getBuahsByTipe(this,jenisBuah);
        inisialisasiView();
        tampilkanProfil();
    }

    private void inisialisasiView() {
        btnPertama = findViewById(R.id.btnPertama);
        btnSebelumnya = findViewById(R.id.btnSebelumnya);
        btnBerikutnya = findViewById(R.id.btnBerikutnya);
        btnTerakhir = findViewById(R.id.btnTerakhir);

        btnPertama.setOnClickListener(view -> buahPertama());
        btnTerakhir.setOnClickListener(view -> buahTerakhir());
        btnSebelumnya.setOnClickListener(view -> buahSebelumnya());
        btnBerikutnya.setOnClickListener(view -> buahBerikutnya());

        txJenis = findViewById(R.id.txJenis);
        txAsal = findViewById(R.id.txAsal);
        txDeskripsi = findViewById(R.id.txDeskripsi);
        ivFotoBuah = findViewById(R.id.gambarBuah);

        txJudul = findViewById(R.id.txJudul);
        txJudul.setText("Berbagai Jenis Buah "+jenisBuah);
    }


    private void tampilkanProfil() {
        Buah b = buahs.get(indeksTampil);
        Log.d("Durian","Menampilkan durian "+b.getJenis());
        txJenis.setText(b.getJenis());
        txAsal.setText(b.getAsal());
        txDeskripsi.setText(b.getDeskripsi());
        ivFotoBuah.setImageDrawable(this.getDrawable(b.getDrawableRes()));
    }

    private void buahPertama() {
        int posAwal = 0;
        if (indeksTampil == posAwal) {
            Toast.makeText(this,"Sudah di posisi pertama",Toast.LENGTH_SHORT).show();
            return;
        } else {
            indeksTampil = posAwal;
            tampilkanProfil();
        }
    }

    private void buahTerakhir() {
        int posAkhir = buahs.size() - 1;
        if (indeksTampil == posAkhir) {
            Toast.makeText(this,"Sudah di posisi terakhir",Toast.LENGTH_SHORT).show();
            return;
        } else {
            indeksTampil = posAkhir;
            tampilkanProfil();
        }
    }

    private void buahBerikutnya() {
        if (indeksTampil == buahs.size() - 1) {
            Toast.makeText(this,"Sudah di posisi terakhir",Toast.LENGTH_SHORT).show();
            return;
        } else {
            indeksTampil++;
            tampilkanProfil();
        }
    }

    private void buahSebelumnya() {
        if (indeksTampil == 0) {
            Toast.makeText(this,"Sudah di posisi pertama",Toast.LENGTH_SHORT).show();
            return;
        } else {
            indeksTampil--;
            tampilkanProfil();
        }
    }
}
