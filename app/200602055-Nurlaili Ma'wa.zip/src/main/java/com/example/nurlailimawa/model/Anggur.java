package com.example.nurlailimawa.model;

public class Anggur extends Buah{

    public Anggur(String nama, String asal, String deskripsi, int drawableRes) {
        super("Anggur",nama,asal,deskripsi,drawableRes);

    }

}