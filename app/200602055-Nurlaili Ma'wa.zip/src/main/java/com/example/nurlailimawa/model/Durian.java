package com.example.nurlailimawa.model;

public class Durian extends Buah{

    public Durian(String nama, String asal, String deskripsi, int drawableRes) {
        super("Durian",nama,asal,deskripsi,drawableRes);

    }

}