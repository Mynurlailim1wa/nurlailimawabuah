package com.example.nurlailimawa.model;

public class Mangga extends Buah{

    public Mangga(String nama, String asal, String deskripsi, int drawableRes) {
        super("Mangga",nama,asal,deskripsi,drawableRes);

    }

}